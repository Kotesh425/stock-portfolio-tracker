# stock-portfolio-tracker
This program tracks your stock portfolio by taking user input for stock symbols and quantities, then calculates the total investment using predefined prices. It optionally saves the summary to a .txt file.
